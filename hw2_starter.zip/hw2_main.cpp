////////////////////////////////////////////////////////
// ECE 2574, Homework 2
//
// File name:   hw2_main.cpp
// Description: This is for exercising a polyline ADT.
// Date:        2/9/2018
//
#include <iostream>		// For cout and cin
#include <string>		// For string objects
#include "Poly.h" 

using namespace std;


int main()
{
	std::cout << "Hello from hw2_main\n";
	return EXIT_SUCCESS;
}

