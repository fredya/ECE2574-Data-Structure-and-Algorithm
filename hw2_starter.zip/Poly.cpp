/////////////////////////////////////////////////////////////
//  HW2 -- starter - ALA 2/2018

/** Implementation file for the class Poly.
 @file Poly.cpp */

#include "Poly.h"
#include "Node.h"
#include <cstddef>

// TO-DO: Implement the default constructor here.
template<class ItemType>
Poly<ItemType>::Poly() 
{
}  // end default constructor

// TO-DO: Implement the copy constructor here.
template<class ItemType>
Poly<ItemType>::Poly(const Poly<ItemType>& aPoly)
{
} // end copy constructor

// TO-DO: Implement the isEmpty method here.
template<class ItemType>
bool Poly<ItemType>::isEmpty() const
{
	return false;
}  // end isEmpty

// TO-DO: Implement the getNumberOfPoints method here.
template<class ItemType>
int Poly<ItemType>::getNumberOfPoints() const
{
	return 0;
}  // end getNumberOfPoints

// TO-DO: Implement the insert method here.  The method must
// insert a node at location 'index', as described in the HW specification.
// No nodes are deleted. If index == 0, then the new node becomes the head node.
// If index == pointCount, then the new node is appended to the tail of the linked list.
template<class ItemType>
bool Poly<ItemType>::insert(const ItemType x, const ItemType y, int index)
{
    return false;
}  // end add

// TO-DO: Implement the remove method here. 
// The node at location 'index', as described in the HW specification, must be removed.
template<class ItemType>
bool Poly<ItemType>::remove(const int index)
{
	return false;
}  // end remove

// TO-DO: Implement the clear method here. 
template<class ItemType>
void Poly<ItemType>::clear()
{
}  // end clear

// TO-DO: Implement the getCoordinateX method here.
// If index is not valid, return -1 (instead of raising an exception).
template<class ItemType>
ItemType Poly<ItemType>::getCoordinateX(const int index) const
{
	return -1;
}

// TO-DO: Implement the getCoordinateY method here.
// If index is not valid, return -1 (instead of raising an exception).
template<class ItemType>
ItemType Poly<ItemType>::getCoordinateY(const int index) const
{
	return -1;
}

// TO-DO: Implement the getArcLength method here.
template<class ItemType>
double Poly<ItemType>::getArcLength() const
{
	return 0.0;
}  // end getArcLength

// TO-DO: Implement the translate method here.
template<class ItemType>
bool Poly<ItemType>::translate(const ItemType deltaX, const ItemType deltaY)
{
	return false;
}

// TO-DO: Implement the destructor here
template<class ItemType>
Poly<ItemType>::~Poly()
{
}


////////////////////////////////////////////////////////////////////////////////////
// overloaded operators

// TO-DO: Implement the operator+ method here
template<class ItemType>
Poly<ItemType>& Poly<ItemType>::operator+(const Poly<ItemType>& rightHandSide) const
{
	Poly<ItemType> *resultPtr;
	return *resultPtr; // Okay to change this statement; it is just a placeholder
}

// TO-DO: Implement the operator= method here
template<class ItemType>
Poly<ItemType>& Poly<ItemType>::operator=(const Poly<ItemType>& rightHandSide) 
{
	return *this; // Okay to change this statement; it is just a placeholder
}

////////////////////////////////////////////////////////////////////////////////////
// private methods

// TO-DO: Implement the getPointerTo method here
template<class ItemType>
Node<ItemType> *Poly<ItemType>::getPointerTo(const int index) const
{
   Node<ItemType> *curPtr;
   return curPtr;
}  // end getPointerTo
