// HW2 starter code for testing
#define CATCH_CONFIG_MAIN			// this line tells Catch to provide a main() function
#define CATCH_CONFIG_COLOUR_NONE	// this line avoids problems due to color-coding the output
#include "catch.hpp"
#include "Poly.h" 

TEST_CASE("Testing empty polyline", "[Poly]") 
{
	INFO("Hint: testing all methods with an empty polyline");

	Poly<int> p;
	REQUIRE(p.isEmpty());
	REQUIRE(p.getNumberOfPoints() == 0);

	REQUIRE(!p.insert(1, 2, -1));
	REQUIRE(!p.insert(1, 2, 1));
	REQUIRE(!p.remove(-1));
	REQUIRE(!p.remove(0));
	REQUIRE(!p.remove(1));
	REQUIRE(p.getCoordinateX(0) == -1);		
	REQUIRE(p.getCoordinateY(0) == -1);
	REQUIRE(p.getArcLength() == 0.0);
	REQUIRE(!p.translate(1, 2));

	INFO("Hint: testing several methods after clearing an empty polyline");
	p.clear();
	REQUIRE(p.isEmpty());
	REQUIRE(p.getNumberOfPoints() == 0);
	REQUIRE(!p.remove(0));
}

TEST_CASE("Testing polyline with a single node", "[Poly]") 
{
	INFO("Hint: testing all methods on a polyline with 1 node");

	Poly<int> p;
	REQUIRE(p.insert(1, 2, 0));

	REQUIRE(!p.isEmpty());
	REQUIRE(p.getNumberOfPoints() == 1);
	REQUIRE(p.getCoordinateX(0) == 1);
	REQUIRE(p.getCoordinateY(0) == 2);
	REQUIRE(p.getArcLength() == 0.0);
	REQUIRE(p.translate(3, 4));
	REQUIRE(p.getCoordinateX(0) == 4);
	REQUIRE(p.getCoordinateY(0) == 6);

	// TO-DO:  add more REQUIRE statements here to test a polyline with 1 node.

}

// TO-DO:  add more TEST_CASEs here to test your code.
